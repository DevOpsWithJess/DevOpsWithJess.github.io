# ---------------------------------------------------------------
# CS 499 Software Design and Engineering Enhancement
# Jessica Johnson
# 05/23/2026
#
# dashboard.py
#
# This file adds a simple Flask web dashboard to the Raspberry Pi
# smart thermostat project. The dashboard is designed to display
# thermostat information in a cleaner and more user-friendly way
# through a web browser instead of only using the LCD display.
#
# The goal of this enhancement is to improve the overall usability
# and organization of the thermostat system while preparing the
# project for future remote monitoring capabilities.
#
# ---------------------------------------------------------------

from flask import Flask
from datetime import datetime

app = Flask(__name__)

#
# Enhancement:
# Simulated thermostat dashboard display
#
# This Flask dashboard was added to make the thermostat information
# easier to view outside of the small LCD screen. It gives the project
# a simple web-based interface and shows how the thermostat could later
# support remote monitoring. Keeping the dashboard in its own file also
# separates the display layer from the thermostat control logic.
#

@app.route('/')
def dashboard():

    dashboardHTML = f"""
    <html>
        <head>
            <title>Smart Thermostat Dashboard</title>
        </head>

        <body style="font-family: Arial; padding: 20px;">

            <h1>Smart Thermostat Dashboard</h1>

            <h2>System Status</h2>

            <p><strong>Mode:</strong> HEAT</p>

            <p><strong>Current Temperature:</strong> 70°F</p>

            <p><strong>Set Point:</strong> 72°F</p>

            <p><strong>Status:</strong> Heating Active</p>

            <p><strong>Last Updated:</strong> {datetime.now()}</p>

        </body>
    </html>
    """

    return dashboardHTML

##
## Run local Flask dashboard
##
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)