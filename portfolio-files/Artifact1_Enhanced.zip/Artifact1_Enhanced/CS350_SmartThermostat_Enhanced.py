# ---------------------------------------------------------------
# CS 350 Emerging Systems Architecture and Technologies
# Jessica Johnson
# 12/11/2025
#
# CS350_SmartThermostat_Enhanced.py
#
# Original Project:
# Smart Thermostat System developed for the CS 350 final project.
# The thermostat uses a Raspberry Pi, temperature sensor, LCD
# display, GPIO buttons, PWM LEDs, and serial communication to
# simulate the functionality of a programmable thermostat.
#
# Thermostat Features:
# - Three operating states: OFF, HEAT, and COOL
# - Real-time temperature monitoring using the AHT20 sensor
# - Adjustable temperature set point controls
# - LCD display showing time, temperature, and thermostat status
# - PWM LED indicators representing active thermostat behavior
# - UART serial communication for thermostat status updates
#
# Enhancement:
# Thermostat Status Data
#
# A centralized status dictionary was added to keep all thermostat
# information in one place. This makes the code easier to maintain
# and allows the dashboard to pull system information from a single
# source instead of tracking data in multiple locations. This design
# also prepares the project for future remote monitoring features
# without requiring major changes to the thermostat control logic.
#
#
# ---------------------------------------------------------------
# Change History
# ---------------------------------------------------------------
# Version | Description
# ---------------------------------------------------------------
# 1.0     Initial Development
# 2.0     Final Thermostat Project Completed
# 3.0     CS 499 Software Design and Engineering Enhancement
# ---------------------------------------------------------------

##
## Import necessary to provide timing in the main loop
##
from time import sleep
from datetime import datetime

##
## Imports required to allow us to build a fully functional state machine
##
from statemachine import StateMachine, State

##
## Imports necessary to provide connectivity to the 
## thermostat sensor and the I2C bus
##
import board
import adafruit_ahtx0

##
## These are the packages that we need to pull in so that we can work
## with the GPIO interface on the Raspberry Pi board and work with
## the 16x2 LCD display
##
# import board - already imported for I2C connectivity
import digitalio
import adafruit_character_lcd.character_lcd as characterlcd

## This imports the Python serial package to handle communications over the
## Raspberry Pi's serial port. 
import serial

##
## Imports required to handle our Button, and our PWMLED devices
##
from gpiozero import Button, PWMLED

##
## This package is necessary so that we can delegate the blinking
## lights to their own thread so that more work can be done at the
## same time
##
from threading import Thread

##
## This is needed to get coherent matching of temperatures.
##
from math import floor

##
## DEBUG flag - boolean value to indicate whether or not to print 
## status messages on the console of the program
## 
DEBUG = False

##
## Enhancement:
## Thermostat Status Data
## This dictionary centralizes thermostat data so it can
## later be shared with a remote monitoring dashboard.
##
thermostatStatus = {
    "mode": "off",
    "currentTemp": 0,
    "setPoint": 72,
    "ledStatus": "off",
    "lastUpdated": ""
}

##
## Create an I2C instance so that we can communicate with
## devices on the I2C bus.
##
i2c = board.I2C()

##
## Initialize our Temperature and Humidity sensor
##
thSensor = adafruit_ahtx0.AHTx0(i2c)

##
## Initialize our serial connection
##
## Because we imported the entire package instead of just importing Serial and
## some of the other flags from the serial package, we need to reference those
## objects with dot notation.
##
## e.g. ser = serial.Serial
##
ser = serial.Serial(
        port='/dev/ttyS0', # This would be /dev/ttyAM0 prior to Raspberry Pi 3
        baudrate = 115200, # This sets the speed of the serial interface in
                           # bits/second
        parity=serial.PARITY_NONE,      # Disable parity
        stopbits=serial.STOPBITS_ONE,   # Serial protocol will use one stop bit
        bytesize=serial.EIGHTBITS,      # We are using 8-bit bytes 
        timeout=1          # Configure a 1-second timeout
)

##
## Our two LEDs, utilizing GPIO 18, and GPIO 23
##
redLight = PWMLED(18)
blueLight = PWMLED(23)


##
## ManagedDisplay - Class intended to manage the 16x2 
## Display
##
## This code is largely taken from the work done in module 4, and
## converted into a class so that we can more easily consume the 
## operational capabilities.
##
class ManagedDisplay():
    ##
    ## Class Initialization method to setup the display
    ##
    def __init__(self):
        ##
        ## Setup the six GPIO lines to communicate with the display.
        ## This leverages the digitalio class to handle digital 
        ## outputs on the GPIO lines. There is also an analagous
        ## class for analog IO.
        ##
        ## You need to make sure that the port mappings match the
        ## physical wiring of the display interface to the 
        ## GPIO interface.
        ##
        ## compatible with all versions of RPI as of Jan. 2019
        ##
        self.lcd_rs = digitalio.DigitalInOut(board.D17)
        self.lcd_en = digitalio.DigitalInOut(board.D27)
        self.lcd_d4 = digitalio.DigitalInOut(board.D5)
        self.lcd_d5 = digitalio.DigitalInOut(board.D6)
        self.lcd_d6 = digitalio.DigitalInOut(board.D13)
        self.lcd_d7 = digitalio.DigitalInOut(board.D26)

        # Modify this if you have a different sized character LCD
        self.lcd_columns = 16
        self.lcd_rows = 2 

        # Initialise the lcd class
        self.lcd = characterlcd.Character_LCD_Mono(self.lcd_rs, self.lcd_en, 
                    self.lcd_d4, self.lcd_d5, self.lcd_d6, self.lcd_d7, 
                    self.lcd_columns, self.lcd_rows)

        # wipe LCD screen before we start
        self.lcd.clear()

    ##
    ## cleanupDisplay - Method used to cleanup the digitalIO lines that
    ## are used to run the display.
    ##
    def cleanupDisplay(self):
        # Clear the LCD first - otherwise we won't be abe to update it.
        self.lcd.clear()
        self.lcd_rs.deinit()
        self.lcd_en.deinit()
        self.lcd_d4.deinit()
        self.lcd_d5.deinit()
        self.lcd_d6.deinit()
        self.lcd_d7.deinit()
        
    ##
    ## clear - Convenience method used to clear the display
    ##
    def clear(self):
        self.lcd.clear()

    ##
    ## updateScreen - Convenience method used to update the message.
    ##
    def updateScreen(self, message):
        self.lcd.clear()
        self.lcd.message = message

    ## End class ManagedDisplay definition  

##
## Initialize our display
##
screen = ManagedDisplay()

##
## TemperatureMachine - This is our StateMachine implementation class.
## The purpose of this state machine is to manage the three states
## handled by our thermostat:
##
##  off
##  heat
##  cool
##
##
class TemperatureMachine(StateMachine):
    "A state machine designed to manage our thermostat"

    ##
    ## Define the three states for our machine.
    ##
    ##  off - nothing lit up
    ##  red - only red LED fading in and out
    ##  blue - only blue LED fading in and out
    ##
    off = State(initial=True)
    heat = State()
    cool = State()

    ##
    ## Default temperature setPoint is 72 degrees Fahrenheit
    ##
    setPoint = 72

    ##
    ## cycle - event that provides the state machine behavior
    ## of transitioning between the three states of our 
    ## thermostat
    ##
    cycle = (
        off.to(heat) |
        heat.to(cool) |
        cool.to(off)
    )

    ##
    ## on_enter_heat - Action performed when the state machine transitions
    ## into the 'heat' state
    ##
    def on_enter_heat(self):
        # Update the LEDs for Heat
        self.updateLights()

        if DEBUG:
            print("* Changing state to heat")

    ##
    ## on_exit_heat - Action performed when the statemachine transitions
    ## out of the 'heat' state.
    ##
    def on_exit_heat(self):
        # Turn off the red LED when leaving heat
        redLight.off()

    ##
    ## on_enter_cool - Action performed when the state machine transitions
    ## into the 'cool' state
    ##
    def on_enter_cool(self):
        # Update the LEDs for Cool
        self.updateLights()

        if DEBUG:
            print("* Changing state to cool")
    
    ##
    ## on_exit_cool - Action performed when the statemachine transitions
    ## out of the 'cool' state.
    ##
    def on_exit_cool(self):
        # Turn off the blue LED when leaving cool
        blueLight.off()

    ##
    ## on_enter_off - Action performed when the state machine transitions
    ## into the 'off' state
    ##
    def on_enter_off(self):
        # Both LEDs are off in the off stat
        redLight.off()
        blueLight.off()

        if DEBUG:
            print("* Changing state to off")
    
    ##
    ## processTempStateButton - Utility method used to send events to the 
    ## state machine. This is triggered by the button_pressed event
    ## handler for our first button
    ##
    def processTempStateButton(self):
        if DEBUG:
            print("Cycling Temperature State")

        # Change the state of the machine post button press
        self.cycle()
        # LEDs match new state
        self.updateLights()

    ##
    ## processTempIncButton - Utility method used to update the 
    ## setPoint for the temperature. This will increase the setPoint
    ## by a single degree. This is triggered by the button_pressed event
    ## handler for our second button
    ##
    def processTempIncButton(self):
        if DEBUG:
            print("Increasing Set Point")

        # Increase setPoint by 1 degree and refresh LEDs
        self.setPoint += 1
        self.updateLights()

    ##
    ## processTempDecButton - Utility method used to update the 
    ## setPoint for the temperature. This will decrease the setPoint
    ## by a single degree. This is triggered by the button_pressed event
    ## handler for our third button
    ##
    def processTempDecButton(self):
        if DEBUG:
            print("Decreasing Set Point")

        # Decrese setPoint by 1 degree and refresh LEDs
        self.setPoint -= 1
        self.updateLights()

    ##
    ## updateLights - Utility method to update the LED indicators on the 
    ## Thermostat
    ##
    def updateLights(self):
        ## Make sure we are comparing temperatires in the correct scale
        temp = floor(self.getFahrenheit())

        ##
        ## Enhancement:
        ## Store current thermostat values in a centralized location.
        ## This allows the dashboard and thermostat logic to reference
        ## the same data source and simplifies future monitoring features.
        ##

        thermostatStatus["mode"] = self.current_state.id
        thermostatStatus["currentTemp"] = temp
        thermostatStatus["setPoint"] = self.setPoint
        thermostatStatus["lastUpdated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Starting point, known state
        redLight.off()
        blueLight.off()
    
        ## Verify values for debug purposes
        if DEBUG:
            print(f"State: {self.current_state.id}")
            print(f"SetPoint: {self.setPoint}")
            print(f"Temp: {temp}")

        # Determine visual identifiers

        # Heat Mode
        #    temp < setPoint -> red LED fading
        #    temp >= setPoint -> red LED solid
        if self.current_state.id == "heat":
            if temp < self.setPoint:
                redLight.pulse(fade_in_time=1, fade_out_time=1, n=None, background=True)

                ## Enhancement:
                ## Store the current heating status so the dashboard can display
                ## system activity without directly accessing thermostat logic.

                thermostatStatus["ledStatus"] = "Heating Active"

            else:
                redLight.on()

                ## Enhancement:
                ## Track idle heating status
                ##
                thermostatStatus["ledStatus"] = "Heat Idle"


        # Cool Mode
        #    temp > setPoint -> blue LED fading
        #    temp <= setPoint -> blud LED solid
        elif self.current_state.id == "cool":
            if temp > self.setPoint:
                blueLight.pulse(fade_in_time=1, fade_out_time=1, n=None, background=True)

                ##
                ## Enhancement:
                ## Track idle cooling status
                ##
                thermostatStatus["ledStatus"] = "Cooling Active"

            else:
                blueLight.on()

                ## 
                ## Enhancement:
                ## Track off state status
                thermostatStatus["ledStatus"] = "System Off"

        # Off Mode
        else:
            redLight.off()
            blueLight.off()

    ##
    ## run - kickoff the display management functionality of the thermostat
    ##
    def run(self):
        myThread = Thread(target=self.manageMyDisplay)
        myThread.start()

    ##
    ## Get the temperature in Fahrenheit
    ##
    def getFahrenheit(self):
        t = thSensor.temperature
        return (((9/5) * t) + 32)
    
    ##
    ##  Configure output string for the Thermostat Server
    ##
    def setupSerialOutput(self):
        # Build comma delimited string: state, current_temp_F, setPoint
        temp_f = floor(self.getFahrenheit())
        output = f"{self.current_state.id},{temp_f},{self.setPoint}"
        return output
    
    ## Enhancement:
    ## Format thermostat data for presentation in the web dashboard.
    ## Separating formatting from control logic improves readability
#   # and makes future dashboard changes easier to implement.

    def getDashboardStatus(self):

        dashboardOutput = (
            f"Mode: {thermostatStatus['mode']}\n"
            f"Current Temp: {thermostatStatus['currentTemp']}F\n"
            f"Set Point: {thermostatStatus['setPoint']}F\n"
            f"System Status: {thermostatStatus['ledStatus']}\n"
            f"Last Updated: {thermostatStatus['lastUpdated']}"
        )

        return dashboardOutput
    
    ## Continue display output
    endDisplay = False

    ##
    ##  This function is designed to manage the LCD Display
    ##
    def manageMyDisplay(self):
        counter = 1
        altCounter = 1
        while not self.endDisplay:
            ## Only display if the DEBUG flag is set
            if DEBUG:
                print("Processing Display Info...")
    
            ## Grab the current time        
            current_time = datetime.now()
    
            ## Setup display line 1
            # Date and time
            lcd_line_1 = current_time.strftime("%m/%d %H:%M")

            ## Setup Display Line 2
            if(altCounter < 6):
                # Show current temperature in Fahrenheit
                temp_f = floor(self.getFahrenheit())
                lcd_line_2 = f"Temp: {temp_f:3d}F"
                altCounter = altCounter + 1
            else:
                # Show current state of setPoint
                state_name = self.current_state.id.capitalize()
                lcd_line_2 = f"{state_name} {self.setPoint:3d}F"
                altCounter += 1
                if(altCounter >= 11):
                    # Update the lights every 10 seconds 
                    self.updateLights()
                    altCounter = 1
    
            ## Update Display: seperated by a new line
            screen.updateScreen(lcd_line_1 + "\n" + lcd_line_2)
    
            ## Update server every 30 seconds
            if DEBUG:
               print(f"Counter: {counter}")
            if((counter % 30) == 0):
                # Send current status to UART
                output = self.setupSerialOutput()
                ser.write((output + "\n").encode("utf-8"))
                counter = 1
            else:
                counter += 1
            sleep(1)

        ## Cleanup display
        screen.cleanupDisplay()

    ## End class TemperatureMachine definition


##
## Setup our State Machine
##
tsm = TemperatureMachine()
tsm.run()


##
## Configure our green button to use GPIO 24 and to execute
## the method to cycle the thermostat when pressed.
##
greenButton = Button(24)
greenButton.when_pressed = tsm.processTempStateButton
##
## Configure our Red button to use GPIO 25 and to execute
## the function to increase the setpoint by a degree.
##
redButton = Button(25)
redButton.when_pressed = tsm.processTempIncButton
##
## Configure our Blue button to use GPIO 12 and to execute
## the function to decrease the setpoint by a degree.
##
blueButton = Button(12)
blueButton.when_pressed = tsm.processTempDecButton
##
## Setup loop variable
##
repeat = True

##
## Repeat until the user creates a keyboard interrupt (CTRL-C)
##
while repeat:
    try:
        ## wait
        sleep(30)

    except KeyboardInterrupt:
        ## Catch the keyboard interrupt (CTRL-C) and exit cleanly
        ## we do not need to manually clean up the GPIO pins, the 
        ## gpiozero library handles that process.
        print("Cleaning up. Exiting...")

        ## Stop the loop
        repeat = False
        
        ## Close down the display
        tsm.endDisplay = True
        sleep(1)
