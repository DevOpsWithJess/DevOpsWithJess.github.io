/**
 * WeightTrack Lite
 * CreateUserActivity.java
 * Create Account Screen
 *
 * Project 2
 * Jessica Johnson  SNHU CS 360  11/30/2025
 * Allows a new user to create an account by entering name, email,
 * password, and password confirmation.
 *
 * Project 3
 * Jessica Johnson  SNHU CS 360  12/12/2025
 * - Validates user input fields
 * - Stores new user credentials in SQLite database
 * - Returns user to login screen after successful account creation
 */

package com.example.weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateUserActivity extends AppCompatActivity {

    private EditText editTextUserName;  // User Name
    private EditText editTextUserEmail;  // User Email
    private EditText editTextCreatePassword;  // User Password
    private EditText editTextConfirmPassword;  // User Password Confirmation
    private Button buttonCreateUser;  // Button to confirm user creation
    private UserDatabaseHelper userDbHelper; // Handles saving user to SQLite

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);
        // initializes database helper
        userDbHelper = new UserDatabaseHelper(this);

        // Connect UI to Java Variables
        editTextUserName = findViewById(R.id.editTextUserName);
        editTextUserEmail = findViewById(R.id.editTextUserEmail);
        editTextCreatePassword = findViewById(R.id.editTextCreatePassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        buttonCreateUser = findViewById(R.id.buttonCreateUser);

        // Validate input upon clicking the Create User button
        buttonCreateUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleCreateUser();
            }
        });

        // Back to Login Button
        Button buttonHome = findViewById(R.id.buttonBackToLogin);
        buttonHome.setOnClickListener(v -> {
            Intent intent = new Intent(CreateUserActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();

        });

    }

    // Validates input and creates new user
    private void handleCreateUser() {
        String name = editTextUserName.getText().toString().trim();
        String email = editTextUserEmail.getText().toString().trim();
        String password = editTextCreatePassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPassword.getText().toString().trim();

        // Check for empty fields
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check for passwords to match
        if (!password.equals(confirmPassword)) {
            editTextConfirmPassword.setError("Passwords do not match");
            Toast.makeText(this, "Passwords do not match.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Try to save the new user in the database
        long newUserId = userDbHelper.createUser(name, email, password);

        if (newUserId == -1) {
            // This usually means the email is already used (UNIQUE constraint failed)
            Toast.makeText(this, "Error creating user. Email may already be in use.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Success message
        Toast.makeText(this, "User created successfully! Please log in.", Toast.LENGTH_SHORT).show();

        // After creating the account, send the user back to the login screen
        Intent intent = new Intent(CreateUserActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}
