/**
 * WeightTrack Lite
 * MainActivity.java
 * Login Screen
 *
 * Project 2
 * Jessica Johnson  SNHU CS 360  11/30/2025
 * Initial login screen for the application. Provides navigation to create an account.
 *
 * Project 3
 * Jessica Johnson  SNHU CS 360  12/12/2025
 * - Validates login input fields
 * - Verifies credentials using SQLite (UserDatabaseHelper)
 * - Navigates to DashboardActivity after successful login
 * - Navigates to CreateUserActivity to create a new account
 */

package com.example.weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Login input fields
    private EditText editTextLoginEmail;
    private EditText editTextLoginPassword;

    // Database helper for validating users
    private UserDatabaseHelper userDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Keep UI in paramerters
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Match EXACT IDs from XML
        editTextLoginEmail = findViewById(R.id.editTextText);               // Email field
        editTextLoginPassword = findViewById(R.id.editTextTextPassword);    // Password field

        // Buttons
        Button buttonLogin = findViewById(R.id.button);      // Log In
        Button buttonCreateAccount = findViewById(R.id.button2); // Create Account

        // Set up the database helper
        userDbHelper = new UserDatabaseHelper(this);

        // Login button
        buttonLogin.setOnClickListener(v -> {
            String email = editTextLoginEmail.getText().toString().trim();
            String password = editTextLoginPassword.getText().toString().trim();

            // Validate input fields
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this,
                        "Please enter both email and password.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate credentials using SQLite database
            long userId = userDbHelper.validateUser(email, password);

            if (userId != -1) {
                // Valid login
                Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                startActivity(intent);
                finish();
            } else {
                // Invalid login
                Toast.makeText(MainActivity.this, "Invalid email or password.", Toast.LENGTH_SHORT).show();
            }
        });

        // Navigate to Create User screen
        buttonCreateAccount.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CreateUserActivity.class);
            startActivity(intent);
        });
    }
}
