/**
 * WeightTrack Lite
 * AddWeightActivity.java
 * Add Weight Screen
 *
 * Project 2
 * Jessica Johnson  SNHU CS 360  11/30/2025
 * Allows the user to enter today's weight and date and saves the entry.
 *
 * Project 3
 * Jessica Johnson  SNHU CS 360  12/12/2025
 * - Saves current weight for dashboard display
 * - Appends each entry to the weight log stored in SharedPreferences
 * - Sends an optional SMS notification when enabled in settings
 */


package com.example.weighttrackingapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.telephony.SmsManager;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.content.Intent;

public class AddWeightActivity extends AppCompatActivity {
    private EditText editTextDate; // Date input
    private EditText editTextWeight; // Weight input

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_weight);

        // Ensures UI doesn't overlap with Status bar
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Connect layout to Java Variables
        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);

        // Save Button
        Button buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        buttonSaveWeight.setOnClickListener(v -> saveWeight());

        // Back to Dashboard Button
        Button buttonHome = findViewById(R.id.buttonHome);
        buttonHome.setOnClickListener(v -> {
            Intent intent = new Intent(AddWeightActivity.this, DashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

    }
    /* Validates input, saves the weight entry, and adds it to
     * SharedPreferences so it will appear in the weight log
     * If SMS enabled, summary text message sent
     */
    private void saveWeight() {
        String weightText = editTextWeight.getText().toString().trim();
        String dateText = editTextDate.getText().toString().trim();

        // Ensure weight field isnt empty
        if (weightText.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter today's weight before saving.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        float weightValue;
        try {
            weightValue = Float.parseFloat(weightText); // Convert weight to a number
        } catch (NumberFormatException e) {
            Toast.makeText(
                    this,
                    "Please enter a valid number.",  // Invalid entry message
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Use todays date, if a date isnt entered
        if (dateText.isEmpty()) {
            dateText = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
                    .format(new Date());
        }

        // Save data to SharedPreferences
        SharedPreferences prefs = getSharedPreferences("WeightPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        // For Dashboard weight
        editor.putFloat("currentWeight", weightValue);

        // For Weight Log: append
        int entryCount = prefs.getInt("entryCount", 0);
        editor.putString("entry_" + entryCount + "_date", dateText);
        editor.putFloat("entry_" + entryCount + "_weight", weightValue);
        editor.putInt("entryCount", entryCount + 1);

        editor.apply();  // Save

        // After saving, check if SMS notifications are enabled
        boolean smsEnabled = prefs.getBoolean("smsEnabled", false);
        String phone = prefs.getString("smsPhoneNumber", "");

        if (smsEnabled && !phone.isEmpty()) {
            // Build the SMS message
            StringBuilder messageBuilder = new StringBuilder();
            messageBuilder.append("Weight Tracking App: New weight logged ")
                    .append(weightValue)
                    .append(" lbs on ")
                    .append(dateText)
                    .append(".");

            // Include goal progress if a goal weight is saved
            float goalWeight = prefs.getFloat("goalWeight", 0f);
            if (goalWeight > 0f) {
                if (weightValue <= goalWeight) {
                    messageBuilder.append(" Congrats! You are at or below your goal of ")
                            .append(goalWeight)
                            .append(" lbs.");
                } else {
                    float diff = weightValue - goalWeight;
                    messageBuilder.append(" You are ")
                            .append(String.format(Locale.getDefault(), "%.1f", diff))
                            .append(" lbs above your goal of ")
                            .append(goalWeight)
                            .append(" lbs.");
                }
            }

            String message = messageBuilder.toString();

            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phone, null, message, null, null);
                // SMS sent successfully
            } catch (Exception e) {
                // If SMS fails app still continues normally
            }
        }

        Toast.makeText(
                this,
                "Weight Saved!", // Success Message
                Toast.LENGTH_SHORT
        ).show();

        // Return to Dashboard
        finish();
    }
}
