/** Jessica Johnson
 * 11/30/2025
 * SNHU CS 360: WeightLoss App
 * Project 2
 *
 * The recycler view uses this adapter to show the saved weight history.
 */

package com.example.weighttrackingapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
 /* Adapter class between the WeightEntry objects and
 *  the RecyclerView in WeightLogActivity
 */
public class WeightLogAdapter extends RecyclerView.Adapter<WeightLogAdapter.WeightLogViewHolder> {

    public interface OnDeleteClickListener {  // Listens for Delete button
        void onDelete(WeightEntry entry);   // Skip the entry that is deleted
    }

    private List<WeightEntry> entries;
    private OnDeleteClickListener deleteClickListener;

    public WeightLogAdapter(List<WeightEntry> entries, OnDeleteClickListener listener) {
        this.entries = entries;
        this.deleteClickListener = listener;
    }
    /* Creates new row for RecyclerView using item_weight_entry.xml*/
    @NonNull
    @Override
    public WeightLogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_entry, parent, false);
        return new WeightLogViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightLogViewHolder holder, int position) {
        WeightEntry entry = entries.get(position);
        // Display the date adn weight for row
        holder.textDate.setText(entry.getDate());
        holder.textWeight.setText(String.format("%.1f lbs", entry.getWeight()));

        // When delete is selected, parent activity is notified
        holder.buttonDelete.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.onDelete(entry);
            }
        });
    }
    // Number of rows the RecyclerView should have
    @Override
    public int getItemCount() {
        return entries != null ? entries.size() : 0;
    }

    // Option to refresh the list with a new set of entries
    public void setEntries(List<WeightEntry> newEntries) {
        this.entries = newEntries;
        notifyDataSetChanged();
    }
    // Static class for UI elements
    static class WeightLogViewHolder extends RecyclerView.ViewHolder {

        TextView textDate; // Displays the date
        TextView textWeight; // Displays the weight
        Button buttonDelete; // Delete button

        public WeightLogViewHolder(@NonNull View itemView) {
            super(itemView);

            // Connect Java variables to their row elements
            textDate = itemView.findViewById(R.id.textItemDate);
            textWeight = itemView.findViewById(R.id.textItemWeight);
            buttonDelete = itemView.findViewById(R.id.buttonDeleteItem);
        }
    }
}
