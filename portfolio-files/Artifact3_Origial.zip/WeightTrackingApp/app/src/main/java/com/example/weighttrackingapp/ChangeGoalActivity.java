/**
 * WeightTrack Lite
 * ChangeGoalActivity.java
 * Change Goal Weight Screen
 *
 * Project 2
 * Jessica Johnson  SNHU CS 360  11/30/2025
 * Allows the user to set or update their goal weight.
 *
 * Project 3
 * Jessica Johnson  SNHU CS 360  12/12/2025
 * - Validates goal weight input
 * - Saves goal weight using SharedPreferences
 * - Returns to the dashboard after updating
 */

package com.example.weighttrackingapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.widget.Button;


public class ChangeGoalActivity extends AppCompatActivity {

    // Input field for goal weight
    private EditText editTextGoalWeightChange;

    // Button to save the new goal weight
    private Button buttonSaveGoalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_change_goal);

        // Keeps the layout within the parameters
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Link UI to Variables
        editTextGoalWeightChange = findViewById(R.id.editTextGoalWeightChange);
        buttonSaveGoalWeight = findViewById(R.id.buttonSaveGoalWeight);

        // When user clicks save, update the goal weight
        buttonSaveGoalWeight.setOnClickListener(v -> saveGoalWeight());

        // Button to return to dashboard
        Button buttonHome = findViewById(R.id.buttonHome);
        buttonHome.setOnClickListener(v -> {
            Intent intent = new Intent(ChangeGoalActivity.this, DashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

    }

     // Validates the goal weight input and saves it to SharedPreferences.
     // Displays appropriate messages if input is invalid.
    private void saveGoalWeight() {
        String goalText = editTextGoalWeightChange.getText().toString().trim();

        // Make sure entry field isn't empty
        if (goalText.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a goal weight.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        float goalValue;
        try {
            goalValue = Float.parseFloat(goalText);
        } catch (NumberFormatException e) {
            Toast.makeText(this,
                    "Please enter a valid number.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        // Weight must be greater than 0
        if (goalValue <= 0) {
            Toast.makeText(this,
                    "Goal weight must be greater than 0.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Save the goal to SharedPreferences
        SharedPreferences prefs = getSharedPreferences("WeightPrefs", MODE_PRIVATE);
        prefs.edit()
                .putFloat("goalWeight", goalValue)
                .apply();

        Toast.makeText(this,
                "Goal weight updated!",
                Toast.LENGTH_SHORT).show();

        // Close and return to dashboard
        finish();
    }
}
