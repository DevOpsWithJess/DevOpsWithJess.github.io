/**
 * WeightTrack Lite
 * SmsSettingActivity.java
 * SMS Notification Settings Screen
 *
 * Project 2
 * Jessica Johnson  SNHU CS 360  11/30/2025
 * Allows the user to enter a phone number and enable/disable SMS notifications.
 *
 * Project 3
 * Jessica Johnson  SNHU CS 360  12/12/2025
 * - Saves SMS settings using SharedPreferences
 * - Requests SEND_SMS permission when needed
 * - Sends a test SMS when notifications are enabled
 * - Returns the user to the dashboard screen
 */

package com.example.weighttrackingapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsSettingActivity extends AppCompatActivity {

    private EditText editTextPhone; // Phone
    private Switch switchSms;  // Toggle Switch
    private Button buttonSaveSms;  // Button to Save

    // Permission request code for SMS
    private static final int SMS_PERMISSION_CODE = 1001;

    // SharedPreferences keys
    private static final String PREFS_NAME = "WeightPrefs";
    private static final String KEY_SMS_ENABLED = "smsEnabled";
    private static final String KEY_SMS_PHONE = "smsPhoneNumber";

    private SharedPreferences prefs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_setting);

        // Connect UI views
        editTextPhone = findViewById(R.id.editTextPhone);
        switchSms = findViewById(R.id.switchSms);
        buttonSaveSms = findViewById(R.id.buttonSaveSms);

        // Set up SharedPreferences
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Load any previously saved SMS settings
        boolean smsEnabled = prefs.getBoolean(KEY_SMS_ENABLED, false);
        String savedPhone = prefs.getString(KEY_SMS_PHONE, "");

        switchSms.setChecked(smsEnabled);
        editTextPhone.setText(savedPhone);

        // Save and test SMS
        buttonSaveSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSaveAndTestSms();
            }
        });

        // Back to dashboard button
        Button buttonHome = findViewById(R.id.buttonHome);
        buttonHome.setOnClickListener(v -> {
            Intent intent = new Intent(SmsSettingActivity.this, DashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    // Validates the phone number and sends test message if SMS is enabled
    private void handleSaveAndTestSms() {
        String phone = editTextPhone.getText().toString().trim();
        boolean isEnabled = switchSms.isChecked();

        // Phone Number
        if (phone.isEmpty()) {
            Toast.makeText(this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save settings regardless of whether SMS is on or off
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_SMS_PHONE, phone);
        editor.putBoolean(KEY_SMS_ENABLED, isEnabled);
        editor.apply();

        // SMS turned off – app continues to run without notifications
        if (!isEnabled) {
            Toast.makeText(
                    this,
                    "SMS notifications are turned off. Settings saved.",
                    Toast.LENGTH_LONG
            ).show();
            return;
        }

        // Check permission before sending SMS
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {

            sendTestSms(phone);

        } else {
            // Request permission from the user
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    // Test SMS text message
    private void sendTestSms(String phone) {
        String message = "Weight Tracking App: This is a test notification for your goal progress.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phone, null, message, null, null);
            Toast.makeText(this, "Test SMS sent (if this device supports SMS).",
                    Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this,
                    "Could not send SMS on this device/emulator.",
                    Toast.LENGTH_LONG).show();
        }
    }

    // Send SMS if permission is granted, if not notify user.
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            // User Allowed SMS
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                String phone = editTextPhone.getText().toString().trim();
                if (!phone.isEmpty() && switchSms.isChecked()) {
                    sendTestSms(phone);
                }

            } else {
                // User clicked deny
                Toast.makeText(this,
                        "SMS permission denied. The app will keep working, but no SMS notifications will be sent.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}
